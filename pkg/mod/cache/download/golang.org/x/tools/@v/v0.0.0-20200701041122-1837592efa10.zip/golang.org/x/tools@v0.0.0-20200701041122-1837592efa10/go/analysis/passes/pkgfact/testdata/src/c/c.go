// want package:`pairs\(audience="world", greeting="hello", pi=3.14159\)`

package c

import _ "b" // want `audience="world" greeting="hello" pi=3.14159`
